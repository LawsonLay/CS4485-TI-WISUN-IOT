################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
/Users/lawsonlay/ti/simplelink_cc13xx_cc26xx_sdk_8_30_01_01/source/ti/ti_wisunfan/ncp_interface/src/ncp/ncp_base_mtd.cpp 

OBJS += \
./wisun_ncp/src/ncp/ncp_base_mtd.o 

CPP_DEPS += \
./wisun_ncp/src/ncp/ncp_base_mtd.d 

OBJS__QUOTED += \
"wisun_ncp/src/ncp/ncp_base_mtd.o" 

CPP_DEPS__QUOTED += \
"wisun_ncp/src/ncp/ncp_base_mtd.d" 

CPP_SRCS__QUOTED += \
"/Users/lawsonlay/ti/simplelink_cc13xx_cc26xx_sdk_8_30_01_01/source/ti/ti_wisunfan/ncp_interface/src/ncp/ncp_base_mtd.cpp" 


