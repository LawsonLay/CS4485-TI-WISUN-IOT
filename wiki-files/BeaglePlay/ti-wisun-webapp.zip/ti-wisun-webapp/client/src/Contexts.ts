import React from 'react';
import {App} from './App';
export const AppContext = React.createContext<App | null>(null);
