################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
/Users/lawsonlay/ti/simplelink_cc13xx_cc26xx_sdk_8_30_01_01/source/third_party/mbed/nanostack/sal-stack-nanostack/source/6LoWPAN/ws/ws_bbr_api.c 

C_DEPS += \
./mbed/nanostack/sal-stack-nanostack/source/6LoWPAN/ws/ws_bbr_api.d 

OBJS += \
./mbed/nanostack/sal-stack-nanostack/source/6LoWPAN/ws/ws_bbr_api.o 

OBJS__QUOTED += \
"mbed/nanostack/sal-stack-nanostack/source/6LoWPAN/ws/ws_bbr_api.o" 

C_DEPS__QUOTED += \
"mbed/nanostack/sal-stack-nanostack/source/6LoWPAN/ws/ws_bbr_api.d" 

C_SRCS__QUOTED += \
"/Users/lawsonlay/ti/simplelink_cc13xx_cc26xx_sdk_8_30_01_01/source/third_party/mbed/nanostack/sal-stack-nanostack/source/6LoWPAN/ws/ws_bbr_api.c" 


